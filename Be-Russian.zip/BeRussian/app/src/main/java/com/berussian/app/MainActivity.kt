package com.berussian.app

import android.app.Activity
import android.media.MediaPlayer
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 20, 29)
    private val panel = Color.rgb(27, 34, 47)
    private val accent = Color.rgb(214, 91, 85)
    private val ink = Color.rgb(240, 243, 248)
    private val muted = Color.rgb(166, 177, 194)
    private var player: MediaPlayer? = null
    private var musicOn = true
    private lateinit var content: LinearLayout
    private lateinit var progressText: TextView
    private val prefs by lazy { getSharedPreferences("berussian", MODE_PRIVATE) }

    data class Lesson(val section: String, val title: String, val subtitle: String, val body: String)
    private val lessons = listOf(
        Lesson("البداية", "الأبجدية الروسية", "33 حرفًا وطريقة نطقها", """الأبجدية الروسية اسمها Кириллица وتتكون من 33 حرفًا.

А а = آ / أ
Б б = ب
В в = ڤ
Г г = ج صلبة قريبة من G
Д д = د
Е е = يِه أو إِه حسب الموضع
Ё ё = يو
Ж ж = ژ
З з = ز
И и = إي
Й й = ي قصيرة
К к = ك
Л л = ل
М м = م
Н н = ن
О о = أو
П п = پ
Р р = ر
С с = س
Т т = ت
У у = أو طويلة
Ф ф = ف
Х х = خ
Ц ц = تس
Ч ч = تش
Ш ш = ش
Щ щ = ش ناعمة ممتدة
Ъ ъ = علامة صلبة
Ы ы = صوت مركزي غير موجود تمامًا بالعربية
Ь ь = علامة تليين
Э э = إيه مفتوحة
Ю ю = يو
Я я = يا

ملاحظة: النطق العربي تقريب تقريبي؛ استمع إلى النطق الأصلي وتدرّب على تمييز الأصوات."""),
        Lesson("البداية", "القراءة والمقاطع", "من الحرف إلى الكلمة", """ابدأ بتمييز الحروف المتشابهة في الشكل:
В = V وليس B
Н = N وليس H
Р = R وليس P
С = S وليس C
У = U وليس Y
Х = Kh وليس X

أمثلة:
мама = ماما
папа = بابا
дом = بيت
кот = قط

اقرأ ببطء، ثم كرر الكلمة بصوت مسموع."""),
        Lesson("الأساسيات", "الضمائر الشخصية", "Я, ты, он…", """Я = أنا
Ты = أنتَ / أنتِ (مفرد غير رسمي)
Он = هو
Она = هي
Оно = هو/هي لغير العاقل المحايد
Мы = نحن
Вы = أنتم / حضرتك
Они = هم

مثال:
Я студент. = أنا طالب.
Она дома. = هي في البيت.

في المضارع غالبًا لا نستخدم فعل «يكون» في الجملة الاسمية."""),
        Lesson("الأساسيات", "جنس الأسماء", "مذكر ومؤنث ومحايد", """غالبًا:
المذكر ينتهي بحرف ساكن: стол (طاولة)
المؤنث ينتهي بـ а أو я: книга (كتاب)
المحايد ينتهي بـ о أو е: окно (نافذة)

هذه قواعد عامة وليست مطلقة؛ توجد استثناءات يجب حفظها مع الكلمة."""),
        Lesson("القواعد", "الحالات الإعرابية الست", "Падежи", """في الروسية تتغير نهاية الاسم والصفة والضمير بحسب وظيفته في الجملة.

1) Именительный — حالة الرفع/الفاعل: Кто? Что?
مثال: Это студент. = هذا طالب.

2) Родительный — حالة الإضافة/الملكية أو النفي: Кого? Чего?
مثال: Нет книги. = لا يوجد كتاب.

3) Дательный — حالة المفعول غير المباشر: Кому? Чему?
مثال: Я даю другу книгу. = أعطي صديقي كتابًا.

4) Винительный — حالة المفعول به: Кого? Что?
مثال: Я читаю книгу. = أقرأ كتابًا.

5) Творительный — حالة الأداة/المصاحبة: Кем? Чем?
مثال: Я пишу ручкой. = أكتب بقلم.

6) Предложный — حالة تأتي غالبًا بعد حروف جر: О ком? О чём? Где?
مثال: Я говорю о книге. = أتحدث عن كتاب.

النهايات تتغير حسب الجنس والعدد ونوع الكلمة؛ سندرس كل حالة في درس مستقل مع جداول وأمثلة."""),
        Lesson("الأفعال", "مقدمة الأفعال", "المصدر والتصريف", """المصدر الروسي غالبًا ينتهي بـ -ть أو -ти أو -чь.
читать = يقرأ
говорить = يتكلم
работать = يعمل

الفعل يتغير حسب الشخص:
Я читаю = أنا أقرأ
Ты читаешь = أنت تقرأ
Он/она читает = هو/هي يقرأ
Мы читаем = نحن نقرأ
Вы читаете = أنتم تقرؤون
Они читают = هم يقرؤون

هذه مجموعة تصريف أولية؛ توجد مجموعات واستثناءات أخرى."""),
        Lesson("الأفعال", "الأزمنة", "الماضي والحاضر والمستقبل", """الروسية الأساسية تميز:
الحاضر: Я читаю — أنا أقرأ.
الماضي: Я читал (مذكر) / Я читала (مؤنث) — قرأت.
المستقبل: Я буду читать — سأقرأ.

جانب الفعل مهم جدًا في الروسية: أفعال غير تامة وأفعال تامة، وسندرس الفرق تدريجيًا.""")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startMusic()
        showHome()
    }

    private fun startMusic() {
        try {
            if (player == null) {
                player = MediaPlayer.create(this, R.raw.ambient)
                player?.isLooping = true
                player?.setVolume(0.22f, 0.22f)
            }
            if (musicOn) player?.start()
        } catch (_: Exception) { }
    }

    private fun stopMusic() { try { player?.pause() } catch (_: Exception) {} }

    private fun baseLayout(title: String): LinearLayout {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(22), dp(20), dp(16))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = title
            textSize = 25f
            setTextColor(ink)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val music = TextView(this).apply {
            text = if (musicOn) "♫ الموسيقى: تعمل" else "♫ الموسيقى: متوقفة"
            textSize = 12f
            setTextColor(if (musicOn) accent else muted)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener {
                musicOn = !musicOn
                if (musicOn) startMusic() else stopMusic()
                showHome()
            }
        }
        header.addView(music)
        outer.addView(header)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(18), 0, dp(12))
        }
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return outer
    }

    private fun showHome() {
        val root = baseLayout("Be Russian")
        val hero = TextView(this).apply {
            text = "Изучай русский\\nتعلّم الروسية خطوة بخطوة"
            textSize = 22f
            setTextColor(ink)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(26), dp(18), dp(26))
            background = rounded(panel, 20)
        }
        content.addView(hero)
        progressText = TextView(this).apply {
            text = "تقدمك: ${prefs.getInt("done", 0)} من ${lessons.size} دروس مكتملة"
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(16), 0, dp(12))
        }
        content.addView(progressText)
        val sections = lessons.map { it.section }.distinct()
        sections.forEach { section ->
            label(section)
            lessons.forEachIndexed { index, lesson ->
                if (lesson.section == section) {
                    val done = prefs.getBoolean("lesson_$index", false)
                    card("${if (done) "✓  " else ""}${lesson.title}", lesson.subtitle) {
                        showLesson(index)
                    }
                }
            }
        }
        label("معلومة سريعة")
        card("طريقة الدراسة", "درس قصير ثم مراجعة واختبار") {
            showLesson(0)
        }
        setContentView(root)
    }

    private fun showLesson(index: Int) {
        val lesson = lessons[index]
        val root = baseLayout("Be Russian")
        val title = TextView(this).apply {
            text = lesson.title
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        }
        content.addView(title)
        val subtitle = TextView(this).apply {
            text = lesson.subtitle
            textSize = 14f
            setTextColor(accent)
            setPadding(0, dp(6), 0, dp(18))
        }
        content.addView(subtitle)
        val body = TextView(this).apply {
            text = lesson.body
            textSize = 17f
            setTextColor(ink)
            setLineSpacing(dp(5).toFloat(), 1f)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(panel, 16)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        }
        content.addView(body)
        val complete = Button(this).apply {
            text = if (prefs.getBoolean("lesson_$index", false)) "تم إكمال الدرس ✓" else "تحديد الدرس كمكتمل"
            setOnClickListener {
                prefs.edit().putBoolean("lesson_$index", true).apply()
                prefs.edit().putInt("done", lessons.indices.count { prefs.getBoolean("lesson_$it", false) }).apply()
                showLesson(index)
            }
        }
        content.addView(complete)
        val next = Button(this).apply {
            text = if (index < lessons.lastIndex) "الدرس التالي ←" else "العودة للرئيسية"
            setOnClickListener { if (index < lessons.lastIndex) showLesson(index + 1) else showHome() }
        }
        content.addView(next)
        val back = TextView(this).apply {
            text = "→ العودة إلى الدروس"
            textSize = 15f
            setTextColor(accent)
            setPadding(0, dp(18), 0, dp(12))
            setOnClickListener { showHome() }
        }
        content.addView(back)
        setContentView(root)
    }

    private fun label(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
            setPadding(0, dp(20), 0, dp(8))
        })
    }

    private fun card(title: String, sub: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(panel, 16)
            setOnClickListener { action() }
        }
        box.addView(TextView(this).apply { text = title; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) })
        box.addView(TextView(this).apply { text = sub; textSize = 13f; setTextColor(muted); setPadding(0, dp(5), 0, 0) })
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(9)
        content.addView(box, lp)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { player?.release() } catch (_: Exception) {}
        player = null
        super.onDestroy()
    }
}
