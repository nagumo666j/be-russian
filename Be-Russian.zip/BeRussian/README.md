# Be Russian — Android starter project

A native Kotlin Android learning-app starter with:
- Arabic-first dark interface
- Introductory Russian lessons (alphabet, reading, pronouns, noun gender, six cases, verbs and tenses)
- Local lesson-completion progress
- Original locally bundled ambient music, enabled on launch with an in-app toggle
- No network permission and no analytics

## Build
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Requirements:
- Android Studio with Android SDK Platform 35
- JDK 17
- Gradle plugin downloads on first sync

The source project is provided; this environment does not have the Android SDK/Gradle installed, so an APK has not been compiled here.

## Notes
This is a functional starter/MVP, not yet a complete Russian course. The lesson content is an introductory foundation. Next development steps: add detailed declension tables by gender/number, aspect pairs, quizzes, pronunciation recordings, and background audio lifecycle controls for background playback.
